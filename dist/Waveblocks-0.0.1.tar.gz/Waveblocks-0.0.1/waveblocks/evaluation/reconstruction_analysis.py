# This file provides functions for analysis of the quality of reconstructed images

# Erik Riedel & Josef Kamysek
# erik.riedel@tum.de & josef@kamysek.com
# 5/11/2020, Munich, Germany

# Python imports
import math
import logging

# Third party libraries
import numpy as np

logger = logging.getLogger("Waveblocks")

def lin_interp(data, i, half):
    return i + ((half - data[i]) / (data[i + 1] - data[i]))

def fwhm_analysis_x(volume, coordinates, distances):
    """
    To use with reconstructed microsphere volume. This function will evalueate the average full width at half maximum of each of the coordinates in X-direction

    volume: reconstructed volume containing microspheres
    coordinates: coordinates of all microsphere centers
    distances: distances between microsphere centers
    """
    hmx = []

    for (x, y, z) in coordinates:
        # select relevant 1 dimensional sample
        data = volume[0, z, :, y]

        # plt.plot(range(len(data)), data)
        # plt.show()

        # crop relevant data
        start = max(0, math.floor((x - (distances / 2))))
        end = min(data.shape[0], math.ceil(x + (distances / 2)))
        data = data[start : end + 1]

        # move data to x-axis
        min_val = np.amin(data)
        data = data - min_val
        half = np.amax(data) / 2.0

        # plt.plot(range(len(data)), data)
        # plt.plot(range(len(data)), np.repeat(half,len(data)))
        # plt.show()

        # compute fwhm
        signs = np.sign(np.add(data, -half))
        zero_crossings = signs[0:-1] != signs[1:]
        zero_crossings_i = np.where(zero_crossings)[0]
        if len(zero_crossings_i) != 2:
            raise RuntimeError(
                "Can not accurately compute fwhm as there are multiple spikes greater than half-maximum"
            )
        hmx.append(
            (
                start + lin_interp(data, zero_crossings_i[0], half),
                start + lin_interp(data, zero_crossings_i[1], half),
                min_val + half
            )
        )
    return hmx

def fwhm_analysis_y(volume, coordinates, distances):
    """
    To use with reconstructed microsphere volume. This function will evalueate the average full width at half maximum of each of the coordinates in Y-direction

    volume: reconstructed volume containing microspheres
    coordinates: coordinates of all microsphere centers
    distances: distances between microsphere centers
    """
    hmy = []

    for (x, y, z) in coordinates:
        # select relevant 1 dimensional sample
        data = volume[0, z, x, :]

        # plt.plot(range(len(data)), data)
        # plt.show()

        # crop relevant data
        start = max(0, math.floor((y - (distances / 2))))
        end = min(data.shape[0], math.ceil(y + (distances / 2)))
        data = data[start : end + 1]

        # move data to x-axis
        min_val = np.amin(data)
        data = data - min_val
        half = np.amax(data) / 2.0

        # plt.plot(range(len(data)), data)
        # plt.plot(range(len(data)), np.repeat(half,len(data)))
        # plt.show()

        # compute fwhm
        signs = np.sign(np.add(data, -half))
        zero_crossings = signs[0:-1] != signs[1:]
        zero_crossings_i = np.where(zero_crossings)[0]
        if len(zero_crossings_i) != 2:
            raise RuntimeError(
                "Can not accurately compute fwhm as there are multiple spikes greater than half-maximum"
            )
        hmy.append(
            (
                start + lin_interp(data, zero_crossings_i[0], half),
                start + lin_interp(data, zero_crossings_i[1], half),
                min_val + half
            )
        )
    return hmy

def fwhm_analysis_z(volume, coordinates, distances):
    """
    To use with reconstructed microsphere volume. This function will evalueate the average full width at half maximum of each of the coordinates in Z direction

    volume: reconstructed volume containing microspheres
    coordinates: coordinates of microsphere center
    distances: distances between microsphere centers
    """
    hmz = []

    for (x, y, z) in coordinates:
        # select relevant 1 dimensional sample
        data = volume[0, :, x, y]

        # plt.plot(range(len(data)), data)
        # plt.show()

        # crop relevant data
        start = max(0, math.floor((z - (distances / 2))))
        end = min(data.shape[0], math.ceil(z + (distances / 2)))
        data = data[start : end + 1]

        # move data to x-axis
        min_val = np.amin(data)
        data = data - min_val
        half = np.amax(data) / 2.0

        # plt.plot(range(len(data)), data)
        # plt.plot(range(len(data)), np.repeat(half,len(data)))
        # plt.show()

        # compute fwhm
        signs = np.sign(np.add(data, -half))
        zero_crossings = signs[0:-1] != signs[1:]
        zero_crossings_i = np.where(zero_crossings)[0]
        if len(zero_crossings_i) != 2:
            raise RuntimeError(
                "Can not accurately compute fwhm as there are multiple spikes greater than half-maximum"
            )
        hmz.append(
            (
                start + lin_interp(data, zero_crossings_i[0], half),
                start + lin_interp(data, zero_crossings_i[1], half),
                min_val + half
            )
        )
    return hmz