import logging
from logging import getLoggerClass, addLevelName, setLoggerClass, NOTSET


class WaveblocksFormatter(logging.Formatter):

    yellow = "\x1b[33;21m"
    red = "\x1b[31;1m"
    reset = "\x1b[0m"

    format_simple = "Waveblocks - %(levelname)s - %(message)s"
    format_advanced = (
        "Waveblocks - %(levelname)s - %(message)s (%(filename)s:%(lineno)d)"
    )

    FORMATS = {
        logging.DEBUG: yellow + format_advanced + reset,
        logging.INFO: format_simple,
        logging.WARNING: red + format_advanced + reset,
        logging.ERROR: red + format_advanced + reset,
    }

    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt)
        return formatter.format(record)


class MyLogger(getLoggerClass()):
    def __init__(self, name, level=NOTSET):
        super().__init__(name, level)
        debug_mla = False
        debug_richardson_lucy = False


setLoggerClass(MyLogger)
