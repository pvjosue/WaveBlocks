# This file provides functions for reconstructing volumes from an image taken by a FLF microscope using Adam optimizer

# Erik Riedel & Josef Kamysek
# erik.riedel@tum.de & josef@kamysek.com
# 5/11/2020, Munich, Germany

# Third party library imports
import torch
import torch.nn.functional as f
import torch.optim as optim
import matplotlib.pyplot as plt

# Waveblocks imports
import waveblocks.utils.complex_operations as co


class Optimizer_Reconstruction:
    def __init__(self, microscope, GT_FLF_img, volume_shape):
        self.microscope = microscope
        self.PSF = self.microscope.psf.float()
        self.GT_FLF_img = GT_FLF_img

        # Setup volume and optimizer
        self.volume_pred = torch.ones(volume_shape, device=self.PSF.device) * 0.5
        self.volume_pred.requires_grad = True
        # optimizer = optim.Adam([volume_pred], lr=0.01)
        self.optimizer = optim.Adam([self.volume_pred], lr=0.1)

        torch.autograd.set_detect_anomaly(True)
        self.crit = torch.nn.MSELoss()

    def forward_fn(self, vol):
        """
        Forward propagation using FFT convolution
        """
        # Pad volume
        GT_volume_pad = f.pad(vol, self.padSizesA)
        GT_volume_pad_fft = torch.rfft(GT_volume_pad, 2, onesided=False)

        conv_res = co.batch_fftshift2d_real(
            torch.irfft(co.mul_complex(GT_volume_pad_fft, self.OTF), 2, onesided=False)
        )
        conv_res_sum = conv_res.sum(1)
        ret = conv_res_sum.unsqueeze(1)
        return ret

    def forward_fn_traditional(self, vol):
        """
        Forward propagation using standard convolution
        """
        conv_res = torch.nn.functional.conv2d(
            self.PSF, vol, padding=(vol.shape[2] - 1)  # // 2
        )
        conv_res_sum = conv_res.sum(1)
        ret = conv_res_sum.unsqueeze(1)
        ret = torch.flip(ret, [2, 3])
        return ret

    def adam_optim(self, num_epochs):
        """
        Reconstruct volume using Adam optimizer
        """
        loss = 0
        loss_plot = []

        for epoch in range(num_epochs):
            img_pred = self.microscope.forward(self.volume_pred, compute_psf=False)

            loss = self.crit(
                img_pred, self.GT_FLF_img
            )  # + img_pred[img_pred < 0].sum().abs() + volume_pred[volume_pred < 0].sum().abs()

            print(
                "loss = "
                + str(loss.sum().item())
                + " - (%.2f%% done)                   " % (100 * epoch / num_epochs),
                end="\r",
            )

            self.optimizer.zero_grad()

            loss.backward()  # retain_graph=True)

            self.optimizer.step()
            loss_plot.append(loss)

        print("loss = " + str(loss.sum().item()))

        plt.plot(range(len(loss_plot)), loss_plot)
        plt.show()

        return self.volume_pred
