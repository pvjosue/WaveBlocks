# Waveblocks imports
from waveblocks.microscopes import BaseMicroscope
from waveblocks.blocks import Lens
from waveblocks.blocks import Camera
from waveblocks.blocks import WavePropagation
from waveblocks.blocks.microlens_arrays import CoordinateMLA
from waveblocks.blocks.microlens_arrays import PeriodicMLA


class Microscope(BaseMicroscope):
    """Implements and extends the abstract base class for a microscope.
    Contains all necessary methods and variables of a furier light field microscope"""

    def __init__(
        self,
        optic_config,
        members_to_learn,
        psf_in,
        mla_coordinates=None,
        mla_shape=None,
    ):
        # Initializes the BaseMicroscope
        super(Microscope, self).__init__(
            optic_config=optic_config,
            members_to_learn=members_to_learn,
            psf_in=psf_in,
            space_variant_psf=False,
        )
        # Initializes microscope specific values
        self.mla_coordinates = mla_coordinates
        self.mla_shape = mla_shape

        # Setup relay
        if self.use_relay:
            self.lens1 = Lens(
                optic_config=self.optic_config,
                members_to_learn=[],
                focal_length=optic_config.relay_focal_length,
                sampling_rate=self.sampling_rate,
                aperture_width=optic_config.relay_aperture_width,
                field_length=self.field_length,
                object_distance=optic_config.relay_focal_length,
                image_distance=optic_config.relay_focal_length,
            )
        else:
            raise Exception("Microscope is missing relay information")

        # Setup MLA
        if self.use_mla:
            # MLA
            if self.mla_type == "coordinateMLA":

                if self.mla_coordinates is None or self.mla_shape is None:
                    raise Exception("Mla coordinates or mla shape missing!")

                self.mla = CoordinateMLA(
                    optic_config=self.optic_config,
                    members_to_learn=[],
                    focal_length=optic_config.fm,
                    pixel_size=self.sampling_rate,
                    image_shape=self.psf_in.shape[2:4],
                    block_shape=optic_config.Nnum,
                    space_variant_psf=self.space_variant_psf,
                    mla_coordinates=self.mla_coordinates,
                    mla_shape=self.mla_shape,
                )

            elif self.mla_type == "periodicMLA":
                self.mla = PeriodicMLA(
                    optic_config=self.optic_config,
                    members_to_learn=[],
                    focal_length=optic_config.fm,
                    pixel_size=self.sampling_rate,
                    image_shape=self.psf_in.shape[2:4],
                    block_shape=optic_config.Nnum,
                    space_variant_psf=self.space_variant_psf,
                    block_separation=optic_config.Nnum,
                    block_offset=0,
                )

            else:
                raise Exception("Microscope is missing mla type information")

            # Propagation
            self.mla2sensor = WavePropagation(
                optic_config=self.optic_config,
                members_to_learn=[],
                sampling_rate=self.sampling_rate,
                shortest_propagation_distance=optic_config.mla2sensor,
                field_length=self.field_length,
            )
        else:
            raise Exception("Microscope is missing mla information")

        # Setup camera
        self.camera = Camera(
            optic_config=self.optic_config,
            members_to_learn=[],
            pixel_size=self.sampling_rate,
            space_variant_psf=self.space_variant_psf,
        )

    def forward(self, real_object, compute_psf=True):
        # Propagate a certain distance
        psf = self.psf_in

        if compute_psf:
            # Check whether relays are used for this microscope
            if self.use_relay:
                # First lens of relay
                psf = self.lens1(psf)
            else:
                raise Exception("Microscope is missing relay information")

            # Check whether a mla is used for this microscope
            if self.use_mla:
                # ob.Debug.debug_psf(psf, 0)

                # Create PSF of MLA
                if self.mla_type == "coordinateMLA":
                    psf_mla = self.mla(psf, self.sampling_rate)

                elif self.mla_type == "periodicMLA":
                    psf_mla = self.mla(psf, self.sampling_rate)

                else:
                    raise Exception("Microscope is missing mla type information")
                # ob.Debug.debug_psf(psf, 0)

                # Propagate MLA to sensor
                psf = self.mla2sensor(psf_mla)
                # ob.Debug.debug_psf(psf_at_sensor, 0)

            # Compute final PSF and convolve with object
        convolved_object, psf, _ = self.camera(real_object, psf, self.mla)

        # else:
        # convolved_object, psf, _ = self.camera(real_object, psf)

        self.psf = psf
        return convolved_object
