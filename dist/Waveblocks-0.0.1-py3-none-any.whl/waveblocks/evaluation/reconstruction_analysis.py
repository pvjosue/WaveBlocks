# This file provides functions for analysis of the quality of reconstructed images

# Erik Riedel & Josef Kamysek
# erik.riedel@tum.de & josef@kamysek.com
# 5/11/2020, Munich, Germany

# Python imports
import math

# Third party libraries
import numpy as np


def lin_interp(data, i, half):
    return i + ((half - data[i]) / (data[i + 1] - data[i]))


def fwhm_analysis_x(volume, coordinates, distances):
    """
    To use with reconstructed microsphere volume. This function will evalueate the average full width at half maximum of each of the coordinates in X-Y as well as in Y-Z direction

    volume: reconstructed volume containing microspheres
    coordinates: coordinates of microsphere center
    distances: distances between microsphere centers
    """
    hmx = []

    for (x, y, z) in coordinates:
        # print(x," " , y, " ",z)
        data = volume[0, z, :, y]

        # plt.plot(range(len(data)), data)
        # plt.show()

        # crop relevant data
        start = max(0, math.floor((x - (distances / 2))))
        end = min(data.shape[0], math.ceil(x + (distances / 2)))
        data = data[start : end + 1]
        # move data to x-axis
        min_val = np.amin(data)
        data = data - min_val
        half = np.amax(data) / 2.0

        # plt.plot(range(len(data)), data)
        # plt.plot(range(len(data)), np.repeat(half,len(data)))
        # plt.show()

        # compute fwhm
        signs = np.sign(np.add(data, -half))
        zero_crossings = signs[0:-2] != signs[1:-1]
        zero_crossings_i = np.where(zero_crossings)[0]
        if len(zero_crossings_i) != 2:
            raise RuntimeError(
                "Can not accurately compute fwhm as there are multiple spikes greater than half-maximum"
            )
        hmx.append(
            (
                start + lin_interp(data, zero_crossings_i[0], half),
                start + lin_interp(data, zero_crossings_i[1], half),
            )
        )
    return hmx
