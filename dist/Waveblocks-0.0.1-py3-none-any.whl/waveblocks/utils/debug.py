# Third party libraries imports
import matplotlib.pyplot as plt


def debug_psf(psf, z):
    plt.imshow(psf[0, z, :, :, 0].detach().cpu().numpy())
    plt.show()


def debug_mla(mla):
    plt.imshow(mla[:, :, 1].detach().numpy())
    plt.show()
